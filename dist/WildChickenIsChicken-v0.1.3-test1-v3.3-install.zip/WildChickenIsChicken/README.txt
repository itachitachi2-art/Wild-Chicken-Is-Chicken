Wild Chicken Is Chicken v0.1.3-test1
7 Days to Die v3.3 検査用ビルド / Compatibility test build

ビルド済みです。このフォルダを導入するだけで使用できます。
This package is ready to install. No compilation is required.

導入
1. ゲームを完全終了し、セーブと旧WildChickenIsChickenフォルダをバックアップ。
2. 本ZIP内のWildChickenIsChickenで旧MODフォルダを置き換える。
   旧版と新版を2個同時に置いたり、古いDLLを混在させたりしないでください。
3. 7 Days to Die v3.3をEAC無効で起動する。
4. 起動ログの [WildChickenIsChicken] v0.1.3-test1 loaded を確認する。
5. まず検査用セーブで下記を確認してください。

操作と検査
・野生鶏の通常の捕獲と運搬、鶏小屋への設置。
・抱えた鶏にセカンダリアクション（標準右クリック）を押して離す。
・2秒バーと音の後に、絞めたニワトリ1個と羽23枚を取得する。
・バー途中で移動・持ち替えしても、二重付与や消失がないこと。
・元スロットが別のアイテムで埋まった場合と、満杯時の付与/ドロップ。
・調理レシピ、セーブ/再読込。

今回の変更
旧版の処理をv3.3のゲームAPI参照で再ビルドしています。
holdingEntityの古いフィールド参照を、現在のプロパティ取得処理へ変更する互換対応です。
絞める操作、2秒演出、報酬、設定、レシピ、画像の内容は変更していません。
起動ログではv0.1.3-test1、ModInfoでは0.1.3と表示されます。

確認状況
実ゲームDLLを参照したビルドと静的API検査は成功しています。
ゲーム内動作、投稿者環境での解消、マルチプレイ、専用サーバー、他MODとの互換性は未確認です。
これは公開リリース前の検査版です。必ずバックアップと検査用セーブを使用してください。

問題が続く場合
正確なゲームバージョン、起動から例外までのログ、導入したMODの版、他のMOD一覧を確認してください。
戻す場合はゲームを完全終了し、バックアップした旧MODを復元してください。

Installation
Close the game and back up your save and existing mod folder. Replace the old
WildChickenIsChicken folder with this one; do not keep duplicate versions.
Launch 7 Days to Die v3.3 with EAC disabled and confirm v0.1.3-test1 in the log.
Test on a disposable save first. Capture/carry a chicken, press and release the
secondary action, and verify the bar, sound, one butchered chicken and 23 feathers.
Also check switching items, full inventory fallback, coop placement, and save/reload.

This candidate was rebuilt against the supplied v3.3 runtime API. Gameplay logic,
configuration and artwork are unchanged. Compilation and static API checks passed;
in-game, multiplayer, dedicated-server and cross-mod validation are still pending.
To roll back, close the game and restore your backed-up previous mod folder.
No game runtime DLLs, source files, or build tools are included.
